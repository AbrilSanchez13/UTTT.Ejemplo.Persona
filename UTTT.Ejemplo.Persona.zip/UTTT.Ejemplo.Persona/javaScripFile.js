﻿function myFunction() {
    document.getElementById("demo").innerHTML = "My First JavaScript Function";
}